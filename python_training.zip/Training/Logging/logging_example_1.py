import logging

FORMAT='%(asctime)s ' \
        '%(module)s ' \
        '%(process)d ' \
        '%(levelname)s ' \
       '%(pathname)s ' \
       '%(name)s ' \
       '%(message)s '
logging.basicConfig(format=FORMAT,
                    level=logging.INFO,
                    filename='mylog_file.txt')

logging.info("This is simple example of logging module")
logging.info("Going to print this as INFO")
logging.warning("This is warning")
logging.error("This is error message")
logging.debug("Debug Message")
logging.critical("This is super critical message")
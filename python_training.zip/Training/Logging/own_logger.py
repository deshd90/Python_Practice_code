import logging


mylogger = logging.getLogger("MYLOGGER")    #### Default logger name is root you can define your own logger with name MYLOGGER
FORMAT='%(asctime)s ' \
        '%(module)s ' \
        '%(process)d ' \
        '%(levelname)s ' \
       '%(pathname)s ' \
       '%(name)s ' \
       '%(message)s '
mylogger.setLevel(logging.DEBUG)
formatter = logging.Formatter(FORMAT)

s1 = logging.StreamHandler()        ##### This will output your logging message to STDOUT
s1.setFormatter(formatter)


s2=logging.FileHandler("new_file.log")  #### provide the another filename
s2.setFormatter(formatter)

mylogger.addHandler(s1)             ##### Adding the STDOUT file handler to your logger
mylogger.addHandler(s2)             ##### Adding the file new_file.log to your logger

mylogger.info("This is simple message")
# Context manager can be implemented using generator function.
# Remember generator function are function having yield statement inside it.
# To use generator as context manager you need to import contextlib python module

import os
import contextlib

@contextlib.contextmanager
def changeDir(newDir):
    oldDir = os.getcwd()
    try:  #### Same as __enter__
        print("Changing Directory from {0} to {1}".format(oldDir,newDir))
        os.chdir(newDir)
        yield
    finally: #### same as __exit__
        print("Changing Directory from {1} to {0}".format(oldDir, newDir))
        os.chdir(oldDir)

with changeDir('/home/keshav/Desktop/Training'):
    print("Inside Context Manager: {}".format(os.getcwd()))
print("Outside Context Manager: {}".format(os.getcwd()))


# Context Manager : Any class which implement __enter__ and __exit__ methods quality to be context manger.
# Context manager are used along with statements
# Example of context manager:
# with open(filename) as fp:
#    do_something

import os
class changeDirectory(object):
    def __init__(self,directory):
        self.old_dir = os.getcwd()
        self.new_dir = directory

    def __enter__(self):
        print("Changing directory from {old_dir} to {new_dir}" \
              .format(new_dir=self.new_dir, old_dir=self.old_dir))
        os.chdir(self.new_dir)

    def __exit__(self, exc_type, exc_val, exc_tb):
        print("Changing directory from {0} to {1}" \
              .format(self.new_dir,self.old_dir))
        os.chdir(self.old_dir)

with changeDirectory('/home/keshav/Desktop/Training'):
    print("Inside Context Manager: {}".format(os.getcwd()))

print("Outside Context Manager: {}".format(os.getcwd()))
from distutils.core import setup, Extension

module1 = Extension('addList',
                    sources = ['adder.c'])

setup (name = 'addList',
       version = '1.0',
       description = 'This is a addList package',
       ext_modules = [module1])


#keshav@keshav-VirtualBox:~/Desktop/Training/CPYTHON$ sudo python3 setup.py install
#running install
#running build
#running build_ext
#running install_lib
#running install_egg_info
#Removing /usr/local/lib/python3.6/dist-packages/addList-1.0.egg-info
#Writing /usr/local/lib/python3.6/dist-packages/addList-1.0.egg-info
#keshav@keshav-VirtualBox:~/Desktop/Training/CPYTHON$

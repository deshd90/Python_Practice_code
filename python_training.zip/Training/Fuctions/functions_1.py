def add(value1,*args,**kwargs):
    print("Value1 = {}".format(value1))
    print("Value2 = {}".format(args[0]))
    print("Value3 = {}".format(kwargs))


if __name__ == "__main__":
    add(6,8,9,10,11,23,100,121,num1=56,num2=90)



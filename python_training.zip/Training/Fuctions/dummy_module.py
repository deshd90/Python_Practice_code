from mymodule import *
#x=700

### LEGB -> LOCAL, ENCLOSING,GLOBAL AND BUILTIN
def outer_function():
    global x

    x = 10
    def inner_function():
        #x=55
        print("This is inner function")
        print("Value of x: {}".format(x))
    inner_function()

def newFun():
    print("Value of x in {} : {}".format(newFun.__name__,x))

outer_function()
newFun()
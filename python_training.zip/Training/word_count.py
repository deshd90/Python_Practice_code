import time

wordCount={}
with open('file1.txt') as fp:
    for line in fp:
        for word in line.strip('\n').split(' '):
            wordCount[word] = wordCount.get(word,0) + 1

print(wordCount)
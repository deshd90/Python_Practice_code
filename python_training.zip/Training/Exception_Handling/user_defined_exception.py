"""
User can define its OWN exception by extending Exception Python Class.

The user need to inherit the Exception class and then write its own custom exception.
"""


class myexception(Exception):
    print("This is my custom exception")

try:
    raise myexception
except myexception:
    print("MyException Raised")
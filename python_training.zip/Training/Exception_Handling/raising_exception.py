"""
User can raise exception inside its code whenever he/she wants.
The exception can be raised use raise

Below is example of raising exception.

"""


def raiseException():
    try:
        raise IndexError
    except IndexError:
        print("IndexError Raised and Captured")

raiseException()
"""
The generic way to handle exception is to use the below structure:
try: except: else: finally:

NOTE: You CANNOT have try: else: you should always use try: except: else:

When try block does NOT resulted in exception the else block will get executed.
In case the try block statements resulted in exception except: block statement get executed.
The else: block statement won't get executed in case of exception.

The statements under finally blocks will ALWAYS get executed whether or not exception is there or NOT.
"""

def getIndex(list1,index):
    value = None
    try:
        value = list1[index]  ### success
    except Exception as e:
        print("Exception Ocurred: {}".format(e.args))
    else:
        print("Value is : {}".format(value))
    finally:
        print("This will going to print finally")

mylist = [1,2,3,5]
print(getIndex(mylist,22))

"""
User can have try: finally: like construct as well.
"""

from simple_exception import fetcher

y='spam'
try:
    fetcher(y,5)
finally:
    print('After Fetch')
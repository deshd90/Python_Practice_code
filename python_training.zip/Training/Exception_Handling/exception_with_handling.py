import traceback

if __name__ == "__main__":
    list1 = [4,9,10]
    try:
        print(list1[4])
    except IndexError:
        print("Index Error Occurred: {}".format(traceback.format_exc()))
    print("Program is exiting")
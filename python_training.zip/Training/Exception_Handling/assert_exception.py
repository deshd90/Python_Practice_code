"""
The assert Statement: When it encounters an assert statement, Python evaluates the accompanying expression,
which is hopefully true. If the expression is false, Python raises an AssertionError exception.
If the assertion fails, Python uses ArgumentExpression as the argument for the AssertionError.

"""
if __name__ == "__main__":
    x=30
    assert x<30,"x is not less than 30"
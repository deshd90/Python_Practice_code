######################################################################
##  ADDING PROGRAM NAME
#####################################################################
#python argument_parser_2.py --help
#usage: myprogram [-h]
#
#optional arguments:
#  -h, --help  show this help message and exit

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram')
    args = parser.parse_args()
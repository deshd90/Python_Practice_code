import argparse
import os

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     #usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')

    parser.add_argument('-f','--filename',required=True)  # Optional Arugment
    parser.add_argument('-e','--expected_word',required=True)

    args = parser.parse_args()
    print("Optional Arugment: {}".format(args.filename))
    print("Positional Argument: {}".format(args.expected_word))

    if not os.path.exists(args.filename):
        print("File: {} does NOT Exists".format(args.filename))
    else:
        print("File: {} exists. Checking {}".format(args.filename,args.expected_word))
        with open(args.filename) as fp: #### equal to fp=open(args.filename)
            for line in fp:
                if args.expected_word in line:
                    print("Word found")
                    break
            else:
                print("Word not found")


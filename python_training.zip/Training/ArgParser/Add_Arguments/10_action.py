#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE the required flag


# Type of actions:
# 1. store
# 2. store_true
# 3. store_false
# 4. store_const
# 5. append
# 6. count
# 7. version
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')

    parser.add_argument('--filename',
                        help='Please specify the filename to parse',
                        metavar='filename',
                        action='append')
    parser.add_argument('--ignorecase',
                        help='Specify this option if you want to ignore the case',
                        action='store_true')
    parser.add_argument('--version',
                        action='version',
                        version='%(prog)s 2.0')
    parser.add_argument('--verbose', '-v',
                        action='count')

    args = parser.parse_args()

    print("Filename provided by user: {}".format(args.filename))
    print("Ignore case: {}".format(args.ignorecase))
    print("Verbose = {}".format(args.verbose))
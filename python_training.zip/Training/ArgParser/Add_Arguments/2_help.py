#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE adding help to optional arguments
#

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')

    parser.add_argument('--filename',help='Provide the filename to parse')  # Optional Arugment
    parser.add_argument('--expected_string',help='Provide the regex string to search in file')  ##Positional Argument

    parser.print_help()
    args = parser.parse_args()
    print("Positional Argument: {}".format(args.expected_string))
    print("Optional Arugment: {}".format(args.filename))
print("Name: {}".format(__name__))
def add(x,y):
    return  x+y

if __name__ == "__main__":
    print("This is main function")


import function_doc


if __name__ == "__main__":
    function_doc.add(5,6)
import first_module

print("Second Module -> This value of __name__: {}".format(__name__))
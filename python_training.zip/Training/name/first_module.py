print("The value of __name__: {}".format(__name__))

def startFunc():
    print("First Module -> __name__ = {}".format(__name__))
    print(dir(__name__))
    print(type(__name__))

if __name__ == "__main__":
    startFunc()
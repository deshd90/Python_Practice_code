#In Python every class can have instance attributes.
#By default Python uses a dict to store an object’s instance attributes.
#This is really helpful as it allows setting arbitrary
# new attributes at runtime.
#
#The dict wastes a lot of RAM. Python can’t just allocate
# a static amount of memory
# at object creation to store all the attributes
#__slots__ to tell Python not to use a dict, and only
# allocate space for a fixed set of attributes.

class A(object):
    __slots__ = ['name','age']
    def __init__(self,name,age):
        self.name = name
        self.age = age

class B(A):
    def __init__(self,name,age,address,profession):
        self.address = address
        self.profession = profession
        super().__init__(name,age)

ob = A('Prakash',30)
#print(ob.__dict__)
print(dir(ob))
print(ob.__slots__)
print("Size: {}".format(ob.__sizeof__()))
print("Name : {} and Age : {}".format(ob.name,ob.age))


ob_B = B("Mohit",30,'Pune','sw engg')
print("Name: {} , age: {}, address: {} and profession: {}".format(ob_B.name,ob_B.age,ob_B.address,ob_B.profession))
ob_B.sex = "male"
print("Size: {}".format(ob_B.__sizeof__()))
print("Name: {} , age: {}, address: {} and profession: {}, sex : {}".format(ob_B.name,ob_B.age,ob_B.address,ob_B.profession,ob_B.sex))
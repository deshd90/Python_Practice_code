var1='string'
var1.
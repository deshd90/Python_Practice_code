x=100
def function1():
    x=300
    print(x)
    def innter():
        print(x)
class myClass(object):
    def __init__(self,name):
        self.name = name

    @classmethod
    def newConstructor(cls,name,age):
        cls.age = age
        return myClass(name)

obj1 = myClass("Prakash")
print(obj1.name)

obj2 = myClass.newConstructor("Mohit",30)
print(obj2.name,obj2.age)
# Higher Order Function : Any function which takes
#  function as argument OR return any function

####################################################################
#
# EXAMPLE OF HIGHER ORDER FUNCTION
#
#
###################################################################

def displayMsg():
    print("Hi! passing this function to higher order")

def add(x,y):
    return x+y

def hOrder1(func):
    '''
    This is higer order function which is accepting function as argument
    :param func: 
    :return: 
    '''
    func()

def hOrder2():
    '''
    This is higher order function returning function
    :return: 
    '''
    return add

hOrder1(displayMsg)
myAdd = hOrder2()
print(myAdd(6,10))
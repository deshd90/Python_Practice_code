def funcCount(orig_func):
    funcCount.count = dict()
    def wrapper(*args):
        funcCount.count[orig_func.__name__] = funcCount.count.get(orig_func.__name__,0) + 1
        result = orig_func(*args)
        print("Function {} called {} times".format(orig_func.__name__,funcCount.count[orig_func.__name__]))
        return result

    funcCount.count[orig_func.__name__] = 0
    print(orig_func.__name__)
    print(funcCount.count)
    return wrapper


@funcCount
def add(x,y):
    print("Adding {} and {}".format(x,y))
    return x+y

@funcCount
def sub(x,y):
    print("Sub {} and {}".format(x,y))
    return x-y

print(add)
print(sub)

add(6,8)
add(9,10)

sub(6,0)
sub(7,2)

add(7,10)

print(funcCount.count.get('add',0))
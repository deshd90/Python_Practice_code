fp = open('abc.txt')

for line in fp:
    print(line)
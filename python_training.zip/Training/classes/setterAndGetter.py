import math
class Circle(object):
    """
    This simple class will going to operate on Circle.
    """

    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi*self.radius**2


obj1 = Circle(14)
print("Aread is : {}".format(obj1.area()))
obj1.radius = 21
print("Aread is : {}".format(obj1.area()))
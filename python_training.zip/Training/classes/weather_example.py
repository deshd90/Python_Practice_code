class Weather(object):
    def __init__(self,temperature):
        self.temperature = temperature

    def displayResult(self):
        print("Result: {}".format(self.temperature))

    @staticmethod
    def tempConverter(temperature):
        return temperature*2

    @classmethod

if __name__ == "__main__":
    ob1 = Weather(34)
    print(ob1.tempConverter(ob1.temperature))
    ob1.displayResult()
    #Weather.displayResult()
    Weateher.
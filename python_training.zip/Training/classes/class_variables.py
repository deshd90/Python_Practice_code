class MyClass(object):
    count=0

    def __init__(self,first):
        MyClass.count=MyClass.count+1
        self.firstName=first
        self.count=1


ob1 = MyClass('mohit')
print(MyClass.count)
ob2=MyClass('prakash')
print(MyClass.count)
print(ob1.__dict__)
print(ob2.__dict__)
import logging

FORMAT = '%(asctime)s %(levelname)s %(message)s'
logging.basicConfig(filename='mylog.txt',level=logging.INFO,format=FORMAT,datefmt='%Y:%m:%d %H:%M:%S')

class Employee(object):
    def __init__(self,first,last,age,designation):
        logging.info("__init__ get called")
        self.first = first
        self.last = last
        self.age = age
        self.designation = designation
        #self.email = '{}.{}@company.com'.format(self.first,self.last)

    @property
    def email(self):
        return '{}.{}@company.com'.format(self.first,self.last)

    @email.setter
    def email(self,value):
        self.email = value

    def __str__(self):
        return "Employee('first','last','age','designation')"

    def __repr__(self):
        return "Employee('{}','{}','{}','{}')".format(self.first,self.last,self.age,self.designation)

    def __len__(self):
        return len(self.first) + len(self.last)

    def __add__(self,other):
        return self.age + other.age

    def __call__(cls):
        print("This is Call Method")



obj1 = Employee("Mohit","Arora",28,"Admin")
obj2 = Employee("Dinesh","Sharma",40,"Admin")
obj1.first = "Anand"
print(obj1.email)
print(callable(obj1))





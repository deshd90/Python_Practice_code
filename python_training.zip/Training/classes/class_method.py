class myClass(object):
    x = 10
    def __init__(self):
        self.name = "Prakash"

    @classmethod
    def classfunc(cls):
        print("This is class method")

if __name__ == "__main__":
    obj1 = myClass()
    print(obj1.name)
    myClass.classfunc()
    obj1.classfunc()

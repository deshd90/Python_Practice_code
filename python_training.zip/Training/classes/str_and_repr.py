'''
1. __init__ -> Initialzation 
2. __new__ -> Create new 
3. @classmethod
4. @staticmethod
5. __str__


'''
import logging
FORMAT = '%(asctime)s %(levelname)s %(message)s'
logging.basicConfig(filename='abc.txt', \
                    format=FORMAT, \
                    level = logging.INFO, \
                    datefmt='%d-%m-%Y %H:%M:%S')

logging.info('This is simple message')


class Employee(object):
    def __init__(self,name,age):
        logging.info('Init method get called')
        self.name = name
        self.age = age

    def __str__(self):
        return 'Employee(name,age)'

    def __repr__(self):
        return 'Employee({},{})' \
            .format(self.name,self.age)

    def __call__(cls):
        print("This is Call Method")


obj = Employee('Praksh',45)
print(callable(obj))
print(obj)
print(repr(obj))
obj()
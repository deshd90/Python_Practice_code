class MyClass(object):
    def __new__(cls,*args,**kwargs):
        print("We are calling __new__")
        return super().__new__(cls)
        #return object.__new__(cls,*args,**kwargs)
        #### python 2.7
        #return super(Myclass,cls).__new__(cls,*args,**kwargs)
    def __init__(self,first,last):
        print("Init is called")
        self.firstName =first
        self.lastName = last

obj1 = MyClass('prakash','mehra')
print(obj1)
import class_method
import datatime.datetime


class_method.myClass.classfunc()
obj1 = class_method.myClass()

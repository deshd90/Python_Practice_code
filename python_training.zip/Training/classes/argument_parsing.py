import argparse

class Employee(object):
    def parseArgs(self):
        parser = argparse.ArgumentParser()
        parser.add_argument("--name")
        parser.add_argument("--age")
        args = parser.parse_args()
        print("Name: {} and Age: {}".format(args.name,args.age))


if __name__ == "__main__":
    ob1 = Employee()
    ob1.parseArgs()
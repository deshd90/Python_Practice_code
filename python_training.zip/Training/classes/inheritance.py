class A(object):
    def __init__(self):
        self.varA = 50

    def myfunction(self):
        print("This is function of class A")

class B(A):
    def __init__(self):
        super().__init__()
        self.varB = 100

    def myfunction(self):
        super().myfunction()   #### You are extending function
        print("This function is defined in class B")

class C(B):
    def __init__(self):
        super().__init__()
        self.varC = 500

obj =C()
print(C.mro())
print(obj.varA)
obj.myfunction()
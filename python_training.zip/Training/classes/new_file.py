import understanding_name
print("Inside new file : {}".format(__name__))
#Decorator : Decorator is a function that
# takes another
# function as an argument
#            Add some kind of functionality and
# then return another function
#            without altering the function

import time
from functools import wraps

def calculate_time(func):
    @wraps(func)
    def wrapper_function():
        startTime = time.time()
        func() ## display()
        totalTime = time.time() - startTime
        print("{} executed for {} seconds".format(func.__name__,totalTime))
    return wrapper_function

def decorator_function(original_function):
    @wraps(original_function)
    def wrapper_function():
        print("Going to Execute Function : {}".format(original_function.__name__))
        original_function() #display()
    return wrapper_function

@calculate_time
@decorator_function
def display():
    print("display function ran!!")

#display = calculate_time(decorator_function(display))
#display = calculate_time(display)


############ Using Decorator
display()


class MyClass(object):
    count=0
    """
    This is simple class to demonstrate python class type
    """
    def __init__(self):
        self.name = "Rishi"
        self.age = 23

if __name__ == "__main__":
    obj1 = MyClass()
    print(obj1)
    objectList = []
    for i in range(10):
       objectList.append(MyClass())
    for i in range(10):
        for key in objectList[i].__dict__:
            print(getattr(objectList[i],key))

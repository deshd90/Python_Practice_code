with open('abc.txt') as fp:    #### fp=open('abc.txt')
    for line in fp:
        print(line)
    #### At exit it will execute fp.close() automatically

print(fp.closed)
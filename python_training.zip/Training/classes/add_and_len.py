class Employee(object):
    def __init__(self, first, last,age,salary):
        self.first = first
        self.last = last
        self.age = age
        self.salary = salary

    def fullname(self):
        return ' '.join([self.first,self.last])

    def __repr__(self):
        return "Employee('{}','{}',{},{})".format(self.first,self.last,self.age,self.salary)

    def __str__(self):
        return "class Employee(first,last,age,salary)"

    def __len__(self):
        return len(self.first) + len(self.last)

    def __add__(self, other):
        return self.salary + other.salary

emp1 = Employee('Amol','Gaikwad',30,45000)
emp2 = Employee("Daksh","Arora",25,18000)
print("Length {}".format(len(emp1)))
#print("Length {}".format(emp1.__len__()))
print("Addition : {}".format(emp1+emp2))

print(Employee.fullname(emp1))
print(emp1)
#print(emp1.__repr__())
#print(emp1.__str__())
#print(repr(emp1))
#print(str(emp1))

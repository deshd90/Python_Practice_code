def add(a,b):
    print("Add {} and {}".format(a,b))
    return a+b

def foo():
    return add

def myadd(func):
    print("This is : {}".format(myadd.__name__))
    func(8,10)


bar = foo()
bar(5,6)
myadd(add)
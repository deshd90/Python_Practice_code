class MyClass(object):
    def __init__(self,first,last):
        self.firstName = first
        self.lastName = last
    def __call__(self, *args, **kwargs):
        print("Implementing call")
        return "python"

obj1 = MyClass('keshav','kushwaha')
print(callable(obj1))
value=obj1()
print("Value: {}".format(value))


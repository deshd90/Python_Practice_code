def bar():
    print("This is bar function")

def foo():
    print("This is mod2 foo function")

from mod1 import foo
foo()
from mod2 import bar,foo

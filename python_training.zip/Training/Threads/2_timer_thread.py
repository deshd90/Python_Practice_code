import threading
import time


def timer(delay,repeat):
    threadName = threading.current_thread().getName()
    print("Timer:{} Started".format(threadName))
    while repeat > 0:
        print("{} : {}".format(threadName, time.ctime(time.time())))
        time.sleep(delay)
        repeat -=1
    print("{} Completed".format(threadName))


def myFunction():
    t1 = threading.Thread(target=timer, args=(3,15),name='myTimer1')
    t2 = threading.Thread(target=timer, args=(5,25),name='myTimer2')
    #for _ in range(100):
    #    t1 = threading.Thread(target=timer, args=(1, 5))
    #    t1.start()
    t1.start()
    t2.start()
    print("This is print from main program")
    t1.join()
    t2.join()
    print("Main Completed")

if __name__ == "__main__":
    myFunction()
import threading



if __name__ == "__main__":
    print("Active Thread Count: {}".format(threading.active_count()))
    ## This function will print Active Thread Count
    print("Current Thread : {}".format(threading.current_thread()))
    ## This function will print the current thread
    print("Main Thread: {}".format(threading.main_thread()))
    ## This function will print the MAIN Thread
    print("Thread ID: {}".format(threading.get_ident()))
    ## This function will print Thread Identification
    print("ALL Thread: {}".format(threading.enumerate()))
    ## This function will print ALL threads
    print("Thread Stack Size: {}".format(threading.stack_size()))
    ## This will print thread stack size. 0 (use platform or configured default)
    print("Thread TIMEOUT: {}".format(threading.TIMEOUT_MAX))
    print("Thread NAME: {}".format(threading.current_thread().getName()))



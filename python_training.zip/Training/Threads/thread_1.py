import threading
import time

def printHi():
    print("Hi!!")
    time.sleep(5)
    print("Exiting Hi!!!")

def printHello():
    print("Hello!!")
    time.sleep(20)
    print("Exiting Hello!!")

if __name__ == "__main__":
    #t1 = threading.Thread(target=printHi,name='printHI')
    #t2 = threading.Thread(target=printHello,name='printHello')
    #t1.start()
    #t2.start()
    print("THIS IS MAIN THREAD")
    print("Waiting for other threads to run")
    print("dfdf")
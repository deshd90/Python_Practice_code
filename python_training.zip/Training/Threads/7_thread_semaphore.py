import threading
import random
import time

sem1 = threading.Semaphore(2)

def threadFunction():
    threadName = threading.current_thread().getName()
    print("Thread {} is running".format(threadName))
    sem1.acquire()
    print("Semaphore Acquired by {}!!".format(threadName))
    sleepTime = random.randint(10,25)
    print("Thread {} going to sleep for {} seconds".format(threadName,sleepTime))
    time.sleep(sleepTime)
    print("Thread {} sleep over. Exiting!!".format(threadName))
    sem1.release()

def main():
    for _ in range(5):
        t1 = threading.Thread(target=threadFunction)
        t1.start()

if __name__ == "__main__":
    main()


import threading
import time

class AsyncWrite(threading.Thread):
    def __init__(self,filename,out):
        threading.Thread.__init__(self)
        self.fileName = filename
        self.out = out

    def run(self):
        with open(self.out,'a') as writefp:
            with open(self.fileName) as readfp:
                for line in readfp:
                    writefp.write("{}".format(line))
        print("Background Thread has completed.Exiting Now!!")

def isPerfect(number):
    """
    :param number: The number to be check for perfect/non perfect
    :return: True if number is perfect else False
    """
    factors = 0
    for integer in range(1,int(number/2)+2):
        if number % integer == 0:
            factors+=integer
    if factors == number:
        return True
    else:
        return False

def main():
    background = AsyncWrite('README.txt','out.txt')
    background.start()
    print("The Program can contiue while it writes in another thread")
    print("Going to print perfect numbers in range(2,10000")
    print(list(filter(isPerfect, range(2, 50000))))
    background.join()
    print("Waited until thread was completed")

if __name__ == "__main__":
    main()
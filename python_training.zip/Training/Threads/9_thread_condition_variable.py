import threading
from collections import deque
import random
import time

tLock = threading.RLock()
items = deque()
items_cv = threading.Condition(tLock)

def producer():
    threadName = threading.current_thread().getName()
    while True:
        # Produce some items
        items_cv.acquire()
        itemValue = random.randint(50,100)
        print("{} thread adding item: {}".format(threadName,itemValue))
        items.append(itemValue)
        print("Items: {}".format(items))
        items_cv.notify()
        items_cv.release()
        print('sleeping for 10 seconds....')
        time.sleep(10)

def consumer():
    threadName = threading.current_thread().getName()
    print("{} Thread Started".format(threadName))
    while True:
        # Consumer an items
        print("{} Acquiring CV".format(threadName))
        items_cv.acquire()
        items_cv.wait()
        item = items.popleft()
        print("{} thread consumed item: {}".format(threadName, item))
        items_cv.release()

if __name__ == "__main__":
    t1 = threading.Thread(target=producer,name='Producer')
    t2 = threading.Thread(target=consumer,name='Consumer')
    t1.start()
    t2.start()
    t1.join()
    t2.join()


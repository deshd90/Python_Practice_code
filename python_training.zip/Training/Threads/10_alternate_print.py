import threading
import time

tLock = threading.Lock()

def timer(name,delay,repeat):
    print("Timer: {} Started".format(name))

    print("{} Acquired the Lock".format(name))
    while repeat > 0:
        time.sleep(delay)
        tLock.acquire()
        print("{} : {}".format(name,time.ctime(time.time())))
        tLock.release()
        repeat -=1
    print("Releasing the Lock")


    print("Timer: {} Completed".format(name))


def main():
    t1 = threading.Thread(target=timer, args=("Timer1",1,5))
    t2 = threading.Thread(target=timer, args=("Timer2", 1, 5))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print("Main Completed")

if __name__ == "__main__":
    main()
def foo():
    print("This is foo...modified")

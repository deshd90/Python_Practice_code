#Decorators
# Closure: A closure is an inner
# function that remember
# and has access to variables
# in local scope in which it was created even
# after the outer function has finished executing
def outer_function():
    message = "Hi"

    def inner_function():
        print(message)
    #inner_function()
    return inner_function

my_func = outer_function()
my_func()   #inner_function()
print(my_func.__name__)

def outer_function_1(msg):
    #message = msg

    def inner_function():
        print(msg)

    return inner_function

'''
hi_func = outer_function_1("Hi!")
hello_func = outer_function_1("Hello!")

hi_func()
hello_func()

print(hi_func.__name__)
print(hello_func.__name__)
'''

def outer_function_2(greeting):
    #msg_greeting = greeting

    def inner_function(message):
        print("{} {}".format(greeting,message))

    return inner_function

hi_func = outer_function_2("Hi!")
hello_func = outer_function_2("Hello!")

hi_func("This is my message")
hello_func("How are you ?")

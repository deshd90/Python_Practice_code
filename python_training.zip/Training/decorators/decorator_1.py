#Decorator : Decorator is a function that
# takes another
# function as an argument
#            Add some kind of functionality and
# then return another function
#            without altering the function
import time
import functools
def decorator_function(original_function):
   def wrapper_function():
        startTime = time.time()
        print("We are going to call {}".format(original_function.__name__))
        original_function() #display()
        print("Time Taken : {}".format(time.time()-startTime))
   return wrapper_function

def display():
    print("display function ran!!")

display = decorator_function(display)
############ Using Decorator
display()
#display()
#print('Name: {}'.format(display))
#print("Time Taken: {}".format(decorator_function.timeDict[display.__name__]))

def args_decor(x):
    def mydecorator(func):
        def wrapper(*args):
            print("Calling Function : {function} with args {arguments}".format(function=func.__name__,arguments=args))
            return func(*args) + x
        return wrapper
    return mydecorator

#@args_decor(4)
def add(x,y):
    return x+y

add = args_decor(4)(add)

for i,j in zip(range(6,21),range(21,36)):

    print(add(i,j))
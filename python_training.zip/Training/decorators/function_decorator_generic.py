def decorator_function(original_function):
    #print("Wrapper executed before original_function: {}".format(original_function.__name__))
    def wrapper_function(*args,**kwargs):
        return original_function(*args,**kwargs)
    return wrapper_function

@decorator_function
def display_info(name,age):
    print("display_info ran with arguments: ({} {})".format(name,age))

@decorator_function
def display():
    print("display function ran!!")


display_info('John',25)
display()
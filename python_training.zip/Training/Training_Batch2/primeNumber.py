def isPrime(number):
    for i in range(2,int(number/2)+1):
        if number % i == 0:
            return False
    return True


if __name__ == "__main__":
    print(list(filter(isPrime,range(2,100))))




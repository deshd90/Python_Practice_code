#myScript.py --filename

import sys
import os

if '--filename' in sys.argv:
    index = sys.argv.index('--filename')
    if len(sys.argv) > index+1:

    else:
        print("")

else:
    print("User has not provided the --filename option")



list1=range(1,7)
str1='simple string'

### In python we have for else construct
for value in list1:
    if value == 10:
        print("10 found in list")
        break
    else:
        print("Value: {}".format(value))
else: #### NO BREAK
    print("Number 10 NOT FOUND")


counter=0
while counter < len(list1):
    print("List Value : {}".format(list1[counter]))
    #counter=counter+1
    counter+=1

for char in str1:
    if char is 'a':
        print('a')
    elif char is 'b':
        print('b')
    else:
        print("print else")

#############



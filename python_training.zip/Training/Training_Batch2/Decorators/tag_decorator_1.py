def tags(tag_name):
    def tags_decorator(func):
        def func_wrapper(name):
            return "<{0}>{1}</{0}>".format(tag_name, func(name))
        return func_wrapper
    return tags_decorator
@tags("b")
def get_text(name):
    return "Hello "+name

if __name__ == "__main__":
    print(get_text("John"))

# Outputs <p>Hello John</p>
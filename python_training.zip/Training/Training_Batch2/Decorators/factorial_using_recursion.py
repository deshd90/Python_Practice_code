def factorial(n):
    """
    This function will calculate the factorial of given number n.
    The factorial is the product of all number from 1 to n
    that is 1*2*3*..*(n-2)*(n-1)*n
    :param x:
    :return: 1*2*3*..*(n-2)*(n-1)*n
    """
    product = 1
    for i in range(1,n+1):
        product = product*i
    return product

def factorialWithRecursion(n):
    """
    This function will calculate the factorial of given number n using RECURSION.
    The factorial is the product of all number from 1 to n
    that is 1*2*3*..*(n-2)*(n-1)*n
    :param x:
    :return: 1*2*3*..*(n-2)*(n-1)*n
    """
    if n == 1:
        return 1
    else:
        return n*factorialWithRecursion(n-1)


if __name__ == "__main__":
    print(factorial(5))
    print(factorialWithRecursion(5))



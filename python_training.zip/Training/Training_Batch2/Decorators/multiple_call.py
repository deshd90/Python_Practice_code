n=20
def multipleTimeCall(n):
    """
    This decorator will going to call given function func 'n' number of times.
    Where n is an integer.
    :param func: Function which user want to call multiple times
    :param n: The number for which times we need to call given function
    :return:
    """
    def wrapper(func):
        def inner_function(message):
            for i in range(1,n+1):
                func(message)
        return inner_function
    return wrapper

@multipleTimeCall(10)
def printMsg(message):
    print("Message : {}".format(message))


if __name__ == "__main__":
    #printMsg = multipleTimeCall(10)(printMsg)
    printMsg("Simple Message")


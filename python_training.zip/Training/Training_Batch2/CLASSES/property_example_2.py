class Employee(object):
    def __init__(self,name):
        self.name = name

    def getName(self):
        print("Calling getter")
        return self._name

    def setName(self,value):
        print("Calling Setter : {}".format(value))
        self._name = value

    name = property(getName, setName)

if __name__ == "__main__":
    ob1 = Employee(name="Mohit")
    print(ob1.name)
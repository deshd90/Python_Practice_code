class Employee(object):
    @classmethod
    def simpleClassMethod(cls):
        print("This method can be called using Class")

    @staticmethod
    def calculateAverage(sal1,sal2,sal3):
        return sum([sal1,sal2,sal3])/3

Employee.simpleClassMethod()
obj1 = Employee()
obj1.salary=23000
print(obj1.calculateAverage(obj1.salary,89,900))
print(Employee.calculateAverage(8,9,1000))
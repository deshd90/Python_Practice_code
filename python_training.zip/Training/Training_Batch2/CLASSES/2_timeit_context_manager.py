import time

class timeIt(object):
    def __init__(self):
        self.totalTime = 0

    def __enter__(self):
        self.startTime = time.time()
        return self

    def __exit__(self,*args):
        self.totalTime = time.time() - self.startTime


if __name__ == "__main__":
    with timeIt() as trackTime:
        print("Inside context manager. Sleeping for 5 seconds")
        time.sleep(5)
        print("Exiting Context Manager")

    print("Total Time: {}".format(int(trackTime.totalTime)))

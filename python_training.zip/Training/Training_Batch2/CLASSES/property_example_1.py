class Employee(object):
    print("Employee class")

    def __init__(self,name,emailID,age):
        self.name = name
        self.emailID = emailID #### changed to property
        self.age = age

    #### Every attribute has 3 methods __get__,__set__ and __del__
    @property   #property(fget=<functionname>,set=<>,delete<>)
    def emailID(self):
        return self._emailID

    @emailID.setter
    def emailID(self,value):
        print("Setting value of emailID: {}".format(value))
        self._emailID = value

    @property
    def age(self):
        print("Getting age")
        return self._age

    @age.setter
    def age(self,value):
        print("Modifying age")
        if value > 18 and value < 60:
            print("Age {} is valid".format(value))
            self._age = value
        else:
            print("Age {} is INVALID".format(value))
            self._age = 18

Object1 = Employee(name="Prakash",emailID='ppatil@gmail.com',age=61)
#print("Age {}".format(Object1.age))


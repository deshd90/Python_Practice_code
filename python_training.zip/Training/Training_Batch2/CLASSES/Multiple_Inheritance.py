class A(object):
    def __init__(self):
        print("CLASS A")
        self.varA = 900
        super().__init__()

    def foo(self):
        print("This is CLASS A Foo")

class B(object):
    def __init__(self):
        print("CLASS B")
        self.varB = 40
        super().__init__()

    def foo(self):
        print("This is CLASS B Foo")

class C(B,A):
    def __init__(self):
        super().__init__()
        self.varC = 60


obj1 = C()
print(C.mro())
print(obj1.__dict__)
obj1.foo()
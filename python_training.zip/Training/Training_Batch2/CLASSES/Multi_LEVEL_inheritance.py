class A(object):
    def __init__(self):
        self.varA = 100

class B(A):
    def __init__(self):
        super().__init__()   ## self.varA = 100
        self.varB = 200

class C(B):
    def __init__(self):
        super().__init__() ## self.varA and self.varB
        self.C = 400

obj1 = C()
print(obj1.__dict__)
setattr(obj1,"name","Prakash")

print(obj1.name)
print("Variable A: {}".format(obj1.varA))


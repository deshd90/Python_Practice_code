import logging

FORMAT = '%(asctime)s %(name)s %(levelname)s %(message)s'
logging.basicConfig(level=logging.DEBUG,format=FORMAT)

def removeElement(list1,element):
    try:
        list1.remove(element)
    except Exception as e:
        logging.error("Got Exception {} since Value {} not in list".format(e.message,element))
    else:
        print("Value {} is REMOVED".format(element))
    finally:
        print("This will always get executed")



if __name__ == "__main__":
    myList=[4,5,90,2,11]
    removeElement(myList,115)
    print("My List: {}".format(myList))
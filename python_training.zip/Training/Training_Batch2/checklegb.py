## LEGB RULE
# L -> LOCAL
# E -> Enclosing
# G -> Global
# B -> Builtin

myVar = 500

def add():
    myVar = 44
    def inner():
        #myVar = 600
        print("MyVar value: {}".format(myVar))
    inner()

if __name__ == "__main__":
    add()

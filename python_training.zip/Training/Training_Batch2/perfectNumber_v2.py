import primeNumber
"""
Perfect number can be calculated using the formula:
pow(2,n-1) * (pow(2,n)-1)
2^n-1 * 2^(n-1)
Where n is prime number.

Example:
if n =2
pow(2,2-1) = 2
pow(2,2) - 1 = 3
2*3 = 6

"""

def perfectNumber(number):
    return pow(2,number-1) * (pow(2,number)-1)

print(list(map(perfectNumber,filter(primeNumber.isPrime,range(2,20)))))
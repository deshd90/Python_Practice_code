fp=open('a.txt')
line='start'

for line in fp.readlines():
    print(line.strip('\n'))
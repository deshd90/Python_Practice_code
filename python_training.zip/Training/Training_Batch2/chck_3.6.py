a='5'
b=6
print(a*b)
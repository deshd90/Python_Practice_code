######################################################################
##  ADDING USAGE
#####################################################################
#python argument_parsing_3.py --help
#usage: myprogram [options]
#
#optional arguments:
#  -h, --help  show this help message and exit

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]')
    args = parser.parse_args()

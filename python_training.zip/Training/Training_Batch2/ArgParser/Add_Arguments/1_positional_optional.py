#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE OPTIONAL AND POSITIONAL ARGUMENTS
#
import os
import argparse

def checkPattern(filename,pattern):
    with open(filename) as fp:
        for line in fp:
            if pattern in line:
                return True
    return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-f','--filename',
                        help="Please provide the File Name",
                        type=str)  # Optional Arugment
    parser.add_argument('-p', '--pattern',
                        help="Please provide the pattern to search in file",
                        type=str)  # Optional Arugment
    args = parser.parse_args()
    print("Positional Argument: {}".format(args.filename))
    print("Positional Argument: {}".format(args.pattern))
    if os.path.exists(args.filename):
        if checkPattern(args.filename,args.pattern):
            print("Pattern {} FOUND in file {}".format(args.pattern,args.filename))
        else:
            print("Pattern NOT FOUND!!!")
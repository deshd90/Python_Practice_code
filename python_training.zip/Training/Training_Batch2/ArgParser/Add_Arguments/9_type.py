#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE specifying the TYPE of the argument
# The type can take values like int,str,float,open(for specifying file type as argument),

import argparse
import os

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')

    #parser.add_argument('--integers',help='Please provide list of integer to get sum',nargs='*',type=open)  # Optional Arugment
    parser.add_argument('--filename',
                        help='Please provide filename to parse something',
                        type=int)
    args = parser.parse_args()



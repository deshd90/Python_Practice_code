#ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])
# THIS PROGRAM DEMONSTRATE the required flag

import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='myprogram',
                                     usage='%(prog)s [options]',
                                     description='This is my description added!!!',
                                     epilog='This message comes at the end')

    parser.add_argument('--os',help='Please specify operating system',choices=['linux','window','ios'])
    args = parser.parse_args()

    print("Operating System: {}".format(args.os))
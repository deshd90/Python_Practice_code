#!/usr/bin/python
import argparse
print(__name__)

def add(number1,number2):
    """
    This is add functioin which will going to add two numbers
    :param number1: This will be the first integer
    :param number2: This will be the second integer
    :return: The sum of two integers number1 and number2
    """
    pass

def parse_arguments():
    parser = argparse.ArgumentParser(prog="MY PROGRAM",
                                     description="This is program to add two numbers",
                                     epilog="This message will appear at end.",
                                     prefix_chars="-+")

    parser.add_argument("+filename",
                        help="Please provide the filename to search pattern",
                        dest="myfile_to_parse",
                        default="search_text.txt",
                        type=open,
                        metavar="filename")
    parser.add_argument("-i","--insensitive",
                        default=False,
                        action="store_true",
                        help="This flag will make your search insensitive",
                        )
    parser.add_argument("--operating_system",
                        choices=["linux", "window"])
    parser.add_argument("--pattern",
                        help="Please provide the pattern to search in file",
                        required=True
                        )
    arguments = parser.parse_args()
    print("Filename: {}".format(arguments.myfile_to_parse))
    print("Insensitive Option: {}".format(arguments.insensitive))

if __name__ == "__main__":
    parse_arguments()
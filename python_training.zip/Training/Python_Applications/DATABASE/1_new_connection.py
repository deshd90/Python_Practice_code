
'''
mysql -u root -p
Enter password: 
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 4
Server version: 5.7.18-0ubuntu0.16.10.1 (Ubuntu)

Copyright (c) 2000, 2016, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.


mysql> show DATABASES;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| Tutorials          |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
5 rows in set (0.02 sec)

mysql> select version();
+-------------------------+
| version()               |
+-------------------------+
| 5.7.18-0ubuntu0.16.10.1 |
+-------------------------+
1 row in set (0.00 sec)

'''

import pymysql  ####pymssql
if __name__ == "__main__":
    # Open database connection
    db = pymysql.connect(host="localhost",user="root",password="keshav",database="Tutorials" )

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    # execute SQL query using execute() method.
    cursor.execute("SELECT VERSION()")

    # Fetch a single row using fetchone() method.
    data = cursor.fetchone()

    print("Database version : {}".format(data))

    # disconnect from server
    db.close()
import pymysql
import csv
from collections import namedtuple
'''
mysql> select * from EMPLOYEE;
+------------+-----------+------+------+---------+
| FIRST_NAME | LAST_NAME | AGE  | SEX  | INCOME  |
+------------+-----------+------+------+---------+
| Prakesh    | Mehta     |   20 | M    |    2000 |
| Mohan      | Prasad    |   22 | M    |   20000 |
| Sagarika   | Ghosh     |   26 | F    |   30000 |
| Susmita    | Sen       |   30 | F    |   50000 |
| Nitin      | Mehta     |   22 | M    |   18000 |
| Pawan      | Verma     |   27 | M    |   27000 |
| Shailesh   | Pawar     |   31 | M    | 1000000 |
| Vinayak    | Pore      |   35 | M    | 1200000 |
| Swati      | Patole    |   25 | F    |   32000 |
| Tammana    | Sharma    |   29 | F    |   29000 |
| Pooja      | Desai     |   24 | F    |  240000 |
+------------+-----------+------+------+---------+
11 rows in set (0.03 sec)

mysql> 

'''
if __name__ == "__main__":
    emp = namedtuple('employee','first_name' 'last_name' 'age' 'sex' 'income')
    # Open database connection
    db = pymysql.connect(host="localhost", user="root", password="keshav", database="Tutorials")

    # prepare a cursor object using cursor() method
    cursor = db.cursor()

    with open('employee_list.txt') as csvfile:
        csvread = csv.reader(csvfile)
        for row in csvread:
            emp.first_name,emp.last_name,emp.age,emp.sex,emp.income = row
            print('Inserting : {}'.format(emp))
            # Prepare SQL query to INSERT a record into the database.
            sql = "INSERT INTO EMPLOYEE" \
                  "(FIRST_NAME,LAST_NAME,AGE,SEX,INCOME)" \
                  " VALUES('{}','{}','{}','{}','{}')".format(emp.first_name,emp.last_name,emp.age,emp.sex,emp.income)

            print("Mysql Query: {}".format(sql))
            try:
                print("Committing Transaction")
                # Execute the SQL command
                cursor.execute(sql)
                # Commit your changes in the database
                db.commit()
            except Exception as e:
                # Rollback in case there is any error
                print("Exception {} occurred".format(e.args))
                db.rollback()
    db.close()
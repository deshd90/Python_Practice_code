import requests
from bs4 import BeautifulSoup


page = requests.get('https://en.wikipedia.org/wiki/States_and_union_territories_of_India')

soup = BeautifulSoup(page.text, 'html.parser')
print(soup.find_all('table'))

for value in soup.find_all('table'):
    for states in value.find_all('a'):
        print(states.get('title'))
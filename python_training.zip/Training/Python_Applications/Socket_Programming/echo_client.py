import socket               # Import socket module
import re

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 1345                # Reserve a port for your service.

s.connect((host, port))
while True:
    message = input(r"Enter message for Server: ")
    s.send(message.encode())
    #### WRITE CODE SO THAT WHEN USER TYPE QUIT or EXIT
    #### break from this loop
    if re.search(r'quit|exit',message,re.I):
        break

s.close
import paramiko

host = "127.0.0.1"                    #hard-coded
port = 22
transport = paramiko.Transport((host, port))

password = "python"                #hard-coded
username = "python"                #hard-coded
transport.connect(username = username, password = password)

sftp = paramiko.SFTPClient.from_transport(transport)
sftp.chdir('/home/python/')
try:
    fileExists = sftp.stat('/home/python/new_dir')
except IOError:
    sftp.mkdir('/home/python/new_dir')

try:
    fileExists = sftp.stat('/home/python/a.txt')
    if fileExists:
        with sftp.open('/home/python/a.txt') as fp:
            for line in fp:
                print("FILE CONTENT: {}".format(line))
except IOError:
    sftp.mkdir('/home/python/new_dir')

print("CURRENT DIRECTORY: {}".format(sftp.getcwd()))
print("LIST DIRECTORIES: {}".format(sftp.listdir('.')))

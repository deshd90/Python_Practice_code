# Prerequisite : You need to install openssh-server to run ssh server on host system

import paramiko
ssh = paramiko.SSHClient()
##### Add below command for below pop up when you try to connect to local or remote server
#The authenticity of host '127.0.0.1 (127.0.0.1)' can't be established.
#ECDSA key fingerprint is SHA256:jWhRFKkp2kiRKelVEmK7eopmfP6c00Rhj8mZad5kcuE.
#Are you sure you want to continue connecting (yes/no)?
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

ssh.connect('127.0.0.1', username='python',password='python')

##### Executing simple command on remote/local host
stdin, stdout, stderr = ssh.exec_command("uptime")
print("UPTIME : {}".format(stdout.readlines()))


stdin, stdout, stderr = ssh.exec_command("sudo dmesg")
stdin.write('python\n')
stdin.flush()
data = stdout.readlines()
for line in data:
    print("DMESG : {}".format(line))




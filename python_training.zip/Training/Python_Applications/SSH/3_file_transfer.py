import paramiko
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('127.0.0.1', username='python',password='python')

sftp = ssh.open_sftp()
sftp.get('/home/python/a.txt', 'myfile.txt')
sftp.close()

sftp = ssh.open_sftp()
sftp.put('1_connecting_client.py','/home/python/received_file/new_file.py')
sftp.close()
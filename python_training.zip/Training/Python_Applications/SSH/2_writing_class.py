import paramiko

class ssh:
    client = None

    def __init__(self, address, username, password):
        print("Connecting to server. {}".format(address))
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(address, username=username, password=password, look_for_keys=False)
        fp = open('command_result.txt', 'a')
    def sendCommand(self, command):

        if (self.client):
            stdin, stdout, stderr = self.client.exec_command(command)
            if stdout:
                for line in stdout.readlines():
                    print("{}".format(line))
                    fp.write(line)
        else:
            print("Connection not opened.")


sshObj = ssh(address='127.0.0.1',username='python',password='python')
sshObj.sendCommand('ls')
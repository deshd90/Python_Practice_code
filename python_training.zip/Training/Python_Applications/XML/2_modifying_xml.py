#ElementTree provides a simple way to build XML documents and write them to files.
# The ElementTree.write() method serves this purpose.

#Once created, an Element object may be manipulated by directly changing its fields (such as Element.text),
# Element.set() -> adding and modifying attributes
# Element.append() -> adding new children
# Element.remove() -> remove elements

import xml.etree.ElementTree as ET

tree = ET.parse('country_data.xml')
root = tree.getroot()


######## Modifying XML attribute value
print("{0} MODIFYING ATTRIBUTE VALUE {0}".format("="*60))
for country in root.iter('country'):
    name = country.attrib
    if name.get('name') == 'Singapore':
        name['name'] = 'India'
    print(name)
tree.write('output.xml')


############# Adding new attribute value
print("{0} ADDING NEW ATTRIBUTE VALUE {0}".format("="*60))
for rank in root.iter('rank'):
    new_rank = int(rank.text) + 1
    rank.text = str(new_rank)
    #rank.set('updated', 'yes')
    print(rank.text)
tree.write('add_attrib.xml')

########### Adding new children
print("{0} ADDING NEW CHILDREN {0}".format("="*60))
new_element="\n\t<country name=\"Pakistan\">\n" \
            "\t\t<rank>1</rank>\n" \
            "\t\t<year>2008</year>\n" \
            "\t\t<gdppc>141100</gdppc>\n" \
            "\t\t<neighbor direction=\"E\" name=\"Sri Lanka\" />\n" \
            "\t</country>\n"
print(new_element)
root.insert(1,ET.fromstring(new_element))
#root.append(ET.fromstring(new_element))
tree.write('new_element.xml',xml_declaration=True)

############# Removing element from xml
print("{0} REMOVING ELEMENTS {0}".format("="*60))
for country in root.findall('country'):
    rank = int(country.find('rank').text)
    if rank > 50:
        root.remove(country)
tree.write('remove_element.xml')




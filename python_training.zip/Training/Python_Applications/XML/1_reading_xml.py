"""
XML is an inherently hierarchical data format, and the most natural way to represent it is with a tree.
ET has two classes for this purpose -
    ElementTree represents the whole XML document as a tree,
    Element represents a single node in this tree.

    Interactions with the whole document (reading and writing to/from files) are usually done on the ElementTree level.
    Interactions with a single XML element and its sub-elements are done on the Element level.
"""
import xml.etree.ElementTree as ET
tree = ET.parse('country_data.xml')
root = tree.getroot()

#### reading data from string
#root = ET.fromstring(country_data_as_string)

print(root)

# As an Element, root has a tag and a dictionary of attributes and text:
print("TAG : {}".format(root.tag))
print("ATTRIBUTE : {}".format(root.attrib))
print("TEXT : {}".format(root.text))

print("{0} ITERATE OVER CHILD {0}".format("="*60))
#It also has children nodes over which we can iterate:
for child in root:
    print(child.tag,child.attrib)

print("{0} ITERATE ALL ELEMENTS {0}".format("="*60))
#Itearte over all elements in xml file
for elem in root.iter():
    print(elem.tag,elem.attrib,elem.text)

print("{0} ITERATE OVER SPECIFIC CHILD {0}".format("="*60))
#Element has some useful methods that help iterate recursively over all the sub-tree below it
# (its children, their children, and so on). For example, Element.iter():

for neighbor in root.iter('neighbor'):
    print(neighbor.attrib)

# Element.findall() finds only elements with a tag which are direct children of the current element.
# Element.find() finds the first child with a particular tag, and Element.text accesses the element’s text content.
#Element.get() accesses the element’s attributes:

print("{0} FINDALL AND FIND {0}".format("="*60))
if root.findall('country'):
    for country in root.findall('country'):
        try:
            rank = country.find('rank').text
            name = country.get('name')
            print("NAME: {} AND RANK = {}".format(name, rank))
        except Exception as e:
            print("RANK NOT FOUND: {}".format(e.args))
else:
    print("country not found")
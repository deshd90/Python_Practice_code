import  json


if __name__ == "__main__":
    with open('employee.json') as ejson:
        emp = json.load(ejson)
        print("Employee Detail: {}".format(emp))
        print("Type of emp: {}".format(type(emp)))
import json
# Json has following functions
# dumps -> This function will dump json object to string
# dump -> This function will dump json object to FILE
# loads -> This function will load json object from string
# load -> This function will load json object from FILE

if __name__ == "__main__":
    json_string = '{"first_name": "Guido", "last_name":"Rossum"}'
    parsed_json = json.loads(json_string)
    print(type(parsed_json))
    print(parsed_json['first_name'])
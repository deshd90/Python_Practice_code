from flask import Flask
app = Flask(__name__)

@app.route('/hello')
##Either use can use app.route or app.add_url_rule to bind URL to FUNCTION.
## Below function hello_world is BIND to / URL
def hello_world():
   return "Hello World!!!!!!!"
#app.add_url_rule('/','hello',hello_world)
if __name__ == '__main__':

    app.run(debug=True)
    ### Use app.run(host='0.0.0.0') so that it can be accessed by outside
# In addition to the default string variable part, rules can be constructed using the following converters
#  int     accepts integer
# float    For floating point value
# path     accepts slashes used as directory separator character

from flask import Flask
app = Flask(__name__)

@app.route('/blog/<int:postID>')
def show_blog(postID):
   return 'Blog Number %d' % postID

@app.route('/rev/<float:revNo>')
def revision(revNo):
   return 'Revision Number %f' % revNo

@app.route('/path/<path:pathValue>')
def show_path(pathValue):
   return 'Revision Number %s' % pathValue

if __name__ == '__main__':
   app.run(debug=True)

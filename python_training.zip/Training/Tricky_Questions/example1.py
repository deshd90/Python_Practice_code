def foo(k):
    print("ID(k) before: {}".format(id(k)))
    k=[1]
    print("ID(k) after: {}".format(id(k)))

q=[0]
print("ID(q): {}".format(id(q)))
foo(q)
print(q)

print("AFTER ID(q): {}".format(id(q)))
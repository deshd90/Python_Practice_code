import re


p = re.compile('\d+')
result = p.findall('12 drummers drumming, 11 pipers piping, 10 lords a-leaping')
print(result)
REGULAR EXPRESSION METACHARACTERS LIST:
 ^ - Starting of the string
 $ - End of the string
[] - Specify a list of character to search(it does not follow the order any character matches)
 . - It is to match a single character except the new line character.
 * - match the character just before(left side of) star zero or any number of times. Maximum 2 billion characters
 + - match the character just before plus one or more number of times
 ? - matches either once or zero times
{m,n}, where m and n are decimal integers. This qualifier means there must be at least m repetitions, and at most n
       default value of m is 0 and n is infinity (i.e. 2 billion characters)
       {0,} is the same as *, {1,} is equivalent to +, and {0,1} is the same as ?
       {3} indicate exact number/occurence of character.

========================================================================================================




\d
Matches any decimal digit; this is equivalent to the class [0-9].
\D
Matches any non-digit character; this is equivalent to the class [^0-9].
\s
Matches any whitespace character; this is equivalent to the class [ \t\n\r\f\v].
\S
Matches any non-whitespace character; this is equivalent to the class [^ \t\n\r\f\v].
\w
Matches any alphanumeric character; this is equivalent to the class [a-zA-Z0-9_].
\W
Matches any non-alphanumeric character; this is equivalent to the class [^a-zA-Z0-9_].


Performing Matches
Once you have an object representing a compiled regular expression, what do you do with it?
Pattern objects have several methods and attributes

Method/Attribute	Purpose
match()	    Determine if the RE matches at the beginning of the string.
search()	Scan through a string, looking for any location where this RE matches.
findall()	Find all substrings where the RE matches, and returns them as a list.
finditer()	Find all substrings where the RE matches, and returns them as an iterator.



Here’s a table of the available flags, followed by a more detailed explanation of each one.

Flag	            Meaning
ASCII,      A	    Makes several escapes like \w, \b, \s and \d match only on ASCII characters with the respective property.
DOTALL,     S	    Make . match any character, including newlines
IGNORECASE, I	    Do case-insensitive matches
LOCALE,     L	        Do a locale-aware match
MULTILINE,  M	    Multi-line matching, affecting ^ and $
VERBOSE,    X       (for ‘extended’)	Enable verbose REs, which can be organized more cleanly and understandably.

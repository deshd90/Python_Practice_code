def yrange(n):
    i = 0
    while(i<n):
        yield i
        i=i+1

if __name__ == "__main__":
    g=yrange(10)
    for i in g:
        print(i)
    """
    print(next(g))
    print(next(g))
    print(next(g))
    print(next(g))
    print(next(g))
    print(next(g))
    print(next(g))
    print(next(g))
    print(next(g))
    print(next(g))
    #print(next(g))
    #print(next(g))
    """
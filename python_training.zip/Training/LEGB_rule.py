#L -> Local
#E -> Enclosing
#G -> Global
#B -> Builtin
#from dummy1 import x
#x=100


def foo():
    #x=200
    def bar():
        #x=500
        print("Value of x={}".format(x))
    #print("Value of x={}".format())
    bar()



foo()
#Serialization is the process of converting a data structure or object state into a format that can be stored
# (for example, in a file or memory buffer, or transmitted across a network connection link)
# and resurrected later in the same or another computer environment.
# When the resulting series of bits is reread according to the serialization format,
# it can be used to create a semantically identical clone of the original object.

#The pickle module implements binary protocols for serializing and de-serializing a Python object structure.
# “Pickling” is the process whereby a Python object hierarchy is converted into a byte stream,
# “unpickling” is the inverse operation, whereby a byte stream (from a binary file or bytes-like object) is converted back into an object hierarchy.
# Pickling (and unpickling) is alternatively known as “serialization”, “marshalling,” [1] or “flattening”;
# however, to avoid confusion, the terms used here are “pickling” and “unpickling”.

#Python has a more primitive serialization module called marshal,
# but in general pickle should always be the preferred way to serialize Python objects.
# marshal exists primarily to support Python’s .pyc files.

#The pickle module differs from marshal in several significant ways:

# 1) The pickle module keeps track of the objects it has already serialized,
#    so that later references to the same object won’t be serialized again. marshal doesn’t do this.

# 2) marshal cannot be used to serialize user-defined classes and their instances.
#    pickle can save and restore class instances transparently,
#    however the class definition must be importable and live in the same module as when the object was stored.


import pickle

list1 = [ x for x in range(100) if x%2 == 0 ]
print(list1)

with open('list1.pickle','wb') as fp:
    pickle.dump(list1,fp)

list1Str = pickle.dumps(list1)
print(type(list1Str))

list2 = pickle.loads(list1Str)
print("List2 : {}".format(list2))
list2.append(9999)
print("List1 : {}".format(list2))
print("List2 : {}".format(list2))

dict1 = {
          'name': "Praksh",
          'age': 34,
           "sex": "male",
           "address" : "Pune",
           "profession": "software engineer"
         }
print(dict1)

with open('dict1.pickle','wb') as fp:
    pickle.dump(dict1,fp)


class A(object):
    def __init__(self,name,age):
        self.name = name
        self.age = age


obj1 = A(name='Goving',age=34)
print("Name : {}".format(obj1.name))
print("Age : {}".format(obj1.age))

with open('classA.pickle','wb') as fp:
    pickle.dump(obj1,fp)